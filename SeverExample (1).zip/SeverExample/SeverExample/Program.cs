﻿using System;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;

namespace SeverExample
{
    class Program
    {
        static void Main(string[] args)
        {
            Socket listner = new Socket(SocketType.Stream, ProtocolType.Tcp);
            //Socket listner = new Socket(AddressFamily.InterNetwork,SocketType.Stream, ProtocolType.Tcp);
            Console.WriteLine("Socket Created");

            IPAddress ipAddress = IPAddress.Loopback;
            //IPAddress ipAddress=IPAddress.Parse("127.0.0.1");
            Console.WriteLine("IP Assigned");

            IPEndPoint ipendpoint = new IPEndPoint(ipAddress, 8001);
            Console.WriteLine("Endpint Ready");
            
            listner.Bind(ipendpoint);
            Console.WriteLine("Socket Bind");
            
            listner.Listen(1);
            Console.WriteLine("Now Listening...");
            
            while (true)
            {
                Socket client = listner.Accept();
                Console.WriteLine("Client Connected");
                Thread th = new Thread(Communicate);
                th.Start(client);
            }
            
            //client.Send(Encoding.ASCII.GetBytes("Welcome to Server"));

            //byte [] dataFromClient=new byte[1024];
            //client.Receive(dataFromClient);
            //Console.WriteLine(Encoding.ASCII.GetString(dataFromClient));

            listner.Close();
            Console.WriteLine("Closed!");

            Console.ReadKey();


        }

        private static void Communicate(object obj)
        {
            Socket soc = (Socket)obj;
            NetworkStream ns = new NetworkStream(soc);
            StreamReader sr = new StreamReader(ns);
            StreamWriter sw = new StreamWriter(ns);

            //Communication
            string data = "";
            while (true)
            {
                data = sr.ReadLine();
                Console.WriteLine(data);

                data = Console.ReadLine();
                sw.WriteLine(data);
                sw.Flush();

            }
            ns.Close();
            soc.Close();
        }
    }
}