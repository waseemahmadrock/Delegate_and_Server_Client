﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DelegateExample
{
    public delegate void ChangeText(string Message);
    public delegate void AddTOList(string Message);

    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        ChangeText changetxt;
        private void button1_Click(object sender, EventArgs e)
        {
            Form2 f2 = new Form2();
            this.changetxt += new ChangeText(f2.doChanges);
            f2.addItemInMain += new AddTOList(addItemInMain);
            f2.Show();
        }

        private void addItemInMain(string Message)
        {
            listBox1.Items.Add(Message);
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            changetxt(textBox1.Text);
        }
        

    }
}
